<html>
	<head>

		<style type="text/css">
			.top {
				text-align: center;
			}
			.down {
				padding-top: 6%;
			}
			
		  </style>

	
	</head>
	<body>
		<div class="top">
			<h1>Verbalizaci&oacute;n de expresiones matem&aacute;ticas</h1>
			<h3>Desde p&aacute;ginas de Wikipedia</h3>

			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
				Ingresa URL: <input type="text" name="url" size=90% /><br/><br/>
				<input type="submit" name="submit" value="Submit" />
			</form>
		</div>

		<div class="down">
			<?php

			$server = $_SERVER["SERVER_NAME"];
			$port = $_SERVER["SERVER_PORT"];
			$page = $_SERVER["PHP_SELF"];

			if(isset($_GET['url']))
			{	
				exec('python reader.py "'.$_GET['url'].'" '.$server." ".$port." ".$page, $salida);

				foreach($salida as $linea)
				{
					echo $linea;
				}
			}
			?>
		</div>
	</body>
</html>
