<?php
header("Content-type: text/xml");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<link rel="stylesheet" href="images/style.css" type="text/css" />
	<title>F&oacute;rmulas matem&aacute;ticas</title>
</head>
<body>
	<div id="page" align="center">
		<div id="header">
			<div id="companyname" align="left">Lectura f&oacute;rmulas matem&aacute;ticas</div>
			<div id="subcompanyname" align="left">"Accesibilidad en expresiones matem&aacute;ticas"</div>
			<div align="right" id="menu">Por Jos&eacute; Sebastian Fuentes Sep&uacute;lveda</div>
		</div>
		<br />
		<div id="content">
			<div id="leftpanel">
				<div class="table_top">
					<span class="title_panel">Links</span>
				</div>
				<div class="table_content">
					<div class="table_text">
						<span class="news_more"><a href="http://www.w3.org/TR/MathML/">MathML</a></span><br /><br/>
						<span class="news_more"><a href="images/Propuesta.pdf">Propuesta</a></span><br /><br/>
					</div>
				</div>
				<div class="table_bottom">
					<img src="images/table_bottom.jpg" width="204" height="23" border="0" alt="" />
				</div>
				<br />
			</div>
			<div id="contenttext">
				<span class="title_blue">Matem&aacute;ticas en la Web</span><br />
				<span class="subtitle_gray">usando MathML</span><br />
				<br />

				<?php
					if(isset($_POST['enviar']))
					{
						echo "<div class=\"message\">Gracias por su participaci&oacute;n</div>";
					}
				?>
				<div id="contenido" align="left">
					<p class="body_text" align="justify">

						Instrucciones:
						<ul>
							<li>Para cada f&oacute;rmula matem&aacute;tica, por favor, escriba la(s) manera(s) en la que usted la lee habitualmente.</li>
							<li>Si usted lee de distintas maneras un expresi&oacute;n, escribalas en orden de uso (de las m&aacute;s usada a la menos usada).</li>
							<li>No es necesario completar todas.</li>
							<li>Por ejemplo 
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mrow>
									  	<mi>F</mi>
									  	<mo>=</mo>
									  	<mrow>
									  		<mi>m</mi>
									  		<mo>&#x2062;</mo>
									  		<mi>a</mi>
									  	</mrow>
									  </mrow>
									</math>
								corresponde a "F igual a m por a".

							</li>
							<li>Se recomienda el uso de FireFox.</li>
						</ul>

						<form method="post" name="formulario" action="<?php echo $_SERVER['PHP_SELF']?>">

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mrow>
									    <mfrac>
									      <mrow>
										<mrow>
										  <mi>x</mi>
										  <mo> + </mo>
										  <mi>1</mi>
										</mrow>
									      </mrow>
									      <mrow>
										<mrow>
										  <mi>x</mi>
										  <mo> - </mo>
										  <mi>1</mi>
										</mrow>
									      </mrow>
									    </mfrac>
									  </mrow>
									</math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mrow>
									    <msup>
									      <mi>x</mi>
									      <mn>3</mn>
									    </msup>
									    <mo> + </mo>
									    <msup>
									      <mi>y</mi>
									      <mn>5</mn>
									    </msup>
									  </mrow>									
									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mroot>
									    <mi>a</mi>
									    <mrow>
									      <mi>n</mi>
									    </mrow>
									  </mroot>									
									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							
							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mrow>
										<mfrac>
										 <mrow>
										  <msup><mo>&#x2202;</mo><mn>2</mn></msup>
										  <mrow>
										   <mi>f</mi>
										   <mo>&#x2061;</mo>
										   <mfenced><mi>x</mi><mi>y</mi></mfenced>
										  </mrow>
										 </mrow>
										 <mrow>
										  <mrow><mo>&#x2202;</mo><mi>x</mi></mrow>
										  <mrow><mo>&#x2202;</mo><mi>y</mi></mrow>
										 </mrow>
										</mfrac>
									  </mrow>
  									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
									  <mrow>
										 <msup><mi>x</mi><mn>2</mn></msup>
										 <mo>&#x2192;</mo>
										 <msup><mi>a</mi><mn>2</mn></msup>
									  </mrow>
  									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <munderover>
										  <mo>&#x2211;</mo>
										  <mrow><mi>x</mi><mo>=</mo><mi>a</mi></mrow>
										  <mi>b</mi>
										 </munderover>
										 <mrow><mi>f</mi><mo>&#x2061;</mo><mfenced><mi>x</mi></mfenced></mrow>
										</mrow>
  									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>


							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <munder>
										  <mo>&#x2211;</mo>
										  <mrow><mi>x</mi><mo>&#x2208;</mo><mi>B</mi></mrow>
										 </munder>
										 <mrow><mi>f</mi><mo>&#x2061;</mo><mfenced><mi>x</mi></mfenced></mrow>
										</mrow>
  									 </math>
								</div>

								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mi>a</mi><mo>&#x2208;</mo><mi>A</mi></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>


							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mrow><mi>&#x222b;</mi><mi>sin</mi></mrow><mo>=</mo><mi>cos</mi></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <msubsup><mi>&#x222b;</mi><mn>0</mn><mn>1</mn></msubsup>
										 <msup><mi>x</mi><mn>2</mn></msup>
										 <mi>d</mi>
										 <mi>x</mi>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>							

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mi>A</mi><mo>&#xd7;</mo><mi>B</mi></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>							

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mn>3</mn><mo>&#x2264;</mo><mn>3</mn><mo>&#x2264;</mo><mn>4</mn></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>							
																											
							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <mi>sin</mi>
										 <mo>&#x2061;</mo>
										 <mrow>
										  <mo>(</mo>
										  <mrow><mi>cos</mi><mo>&#x2061;</mo><mi>x</mi></mrow>
										  <mo>+</mo>
										  <msup><mi>x</mi><mn>3</mn></msup>
										  <mo>)</mo>
										 </mrow>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>							


							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><msub><mi>log</mi><mn>3</mn></msub><mo>&#x2061;</mo><mi>x</mi><mo>+</mo><mi>ln</mi><mo>&#x2061;</mo><mi>a</mi></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>							

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mi>A</mi><mo>&#x2297;</mo><mi>B</mi></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>
							
							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <munder>
										  <mi>lim</mi>
										  <mrow><mi>x</mi><mo>&#x2192;</mo><mn>0</mn></mrow>
										 </munder>
										 <mrow><mi>sin</mi><mo>&#x2061;</mo><mi>x</mi></mrow>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>


							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <mi>&#x3c0;</mi>
										 <mo>&#x2243;</mo>
										 <mrow><mn>22</mn><mo>/</mo><mn>7</mn></mrow>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <mo>&#x2200;</mo>
										 <mi>x</mi>
										 <mo>:</mo>
										 <mfenced>
										  <mrow>
										   <mrow><mi>x</mi><mo>&#x2212;</mo><mi>x</mi></mrow>
										   <mo>=</mo>
										   <mn>0</mn>
										  </mrow>
										 </mfenced>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <mrow>
										  <mrow><mo>(</mo><mi>f</mi><mo>&#x2218;</mo><mi>g</mi><mo>)</mo></mrow>
										  <mo>&#x2061;</mo>
										  <mfenced><mi>x</mi></mfenced>
										 </mrow>
										 <mo>=</mo>
										 <mrow>
										  <mi>f</mi>
										  <mo>&#x2061;</mo>
										  <mfenced>
										   <mrow>
										    <mi>g</mi>
										    <mo>&#x2061;</mo>
										    <mfenced><mi>x</mi></mfenced>
										  </mrow>
										 </mfenced>
										 </mrow>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>
							
							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow>
										 <mi>a</mi>
										 <mo>&#x2261;</mo>
										 <mrow><mo>&#xac;</mo><mrow><mo>&#xac;</mo><mi>a</mi></mrow></mrow>
										</mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>

							<div class="box">
								<div class="leftside">
									<math xmlns="http://www.w3.org/1998/Math/MathML">
										<mrow><mn>4</mn><mo>&#x2265;</mo><mn>3</mn><mo>&#x2265;</mo><mn>3</mn></mrow>
  									 </math>
								</div>
								<div class="rightside">
									<textarea rows="5" cols="50" name="formula[]"></textarea>
								</div>
							</div>
							
							<input type="submit" value="Enviar" name="enviar"/>
						</form>
					</p>
				</div>

				<?php
					if(isset($_POST['enviar']))
					{

						$names = array('divide', 'power', 'root', 'partialdiff', 'tendsto', 'sum1', 'sum2', 'in', 'int1', 'int2', 'cartesianproduct', 'leq', 'sin_cos', 'log_ln', 'outerproduct',
								'limit', 'approx', 'forall', 'compose', 'equivalent', 'geq');
						$cont = 0;
						$archivo = fopen("salida_formulas", "a");
						$string= "##### Nuevos Resultados #####\n";

						$string = $string.date('D F Y, H:i:s');

						foreach($_POST['formula'] as $formula)
						{
							$string = $string."\n".$names[$cont].": ".$formula;
							$cont++;
						}

						$string = $string."\n\n";

						fwrite($archivo, $string);
						fclose($archivo);

					}
				?>
			</div>
			<br />
			<br />
			<div class="footer">
				<br />
				Contactos a jfuentess@udec.cl - fs.pepe@gmail.com
			</div>
		</div>
	</div>
</body>
</html>


